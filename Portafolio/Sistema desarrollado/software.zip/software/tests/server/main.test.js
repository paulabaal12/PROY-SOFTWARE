import { assert } from 'chai';

describe('My Server Tests', function () {
  it('should do something correctly', function () {
    // Prueba que debería pasar
    assert.equal(1, 1);
  });
});
